# DAX time registration

## Install upgrade

Add the repository.

```sh
helm repo add dax https://daxgrid.github.io/charts/
helm repo update
```

Create a values file with the users that can log in.

```yaml
users:
  - username: jla
    password: change-me
    initials: JLA
```

Example of installing it with overridden parameters.

```sh
helm upgrade --install dax-time-registration dax/dax-time-registration \
     --namespace my-namespace \
     -f my-values.yaml
```

The customers, projects and registrations are stored in a persistent volume mounted at `/data`. Back it up, it is the only copy of the data.
A new install starts with no customers, they can be added on the "Customers & projects" page or by copying JSON files into the volume.
The volume is kept on `helm uninstall`, delete it by hand if the data is no longer needed.
